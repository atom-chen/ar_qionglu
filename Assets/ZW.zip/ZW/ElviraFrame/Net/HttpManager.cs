﻿using LitJson;

/**
 *Copyright(C) 2015 by DefaultCompany
 *All rights reserved.
 *FileName:     HttpManager.cs
 *Author:       若飞
 *Version:      1.0
 *UnityVersion：5.3.2f1
 *Date:         2017-04-27
 *Description:
 *History:
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;




namespace ElviraFrame.Net {

    public class HttpManager : Singleton<HttpManager>
    {
        
 

    }
}