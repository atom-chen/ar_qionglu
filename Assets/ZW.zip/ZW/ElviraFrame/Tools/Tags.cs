﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tags
{
    public static string Light = "Light";

}
