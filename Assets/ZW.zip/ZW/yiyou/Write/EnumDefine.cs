﻿public enum GoodsWriteEnum
{
    None,
    Single,
    Two,
    Three
}
public enum PlaneMode
{None,//直接放
    GROUND,//机器人
    MIDAIR//空中

}




public enum ChangeSliderEnum
{

    None,
    Intensity,//亮度
    Light,//灯方向
    Scale//模型大小



}



public enum LoginUIState
{
    LoginPanel,
    RegistPanel,
    ForgetPwdPanel,
    ChangePwPanel,
    AgressPage,
    BinDingPhonePage
}