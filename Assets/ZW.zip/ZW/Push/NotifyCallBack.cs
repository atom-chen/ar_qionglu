﻿/// <summary>
/// 系统通知的内容
/// </summary>
public class NotifyCallBack
{

    /// <summary>
    /// 对应的id
    /// </summary>
    public string id { get; set; }
}