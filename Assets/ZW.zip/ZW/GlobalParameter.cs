﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalParameter
{

    public static string ak = "YPFhLMn0AZgjAtydA3qhZ4snPc6vQtjn";
    public static string htmlPath = "CustomOverlay.html";

    public static string functionName = "PointOverlap";



    public static int maxCount = 4;
    public static int rowOffset = 320;
    public static string LinkWebURL = "http://47.104.182.82:7070/share/nav/ar?mobid=";
    public static string defaultFont = "songti";

    public static bool isNeedRestore = false;

}
